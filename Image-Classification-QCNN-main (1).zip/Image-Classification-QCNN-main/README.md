# Image-Classification-QCNN
Simulation of training a quantum convolutional neural network on the Fashion MNIST dataset to classify images

This project code is based on this [research paper](https://arxiv.org/abs/2108.00661)  
Please find the summary of the project in the powerpoint presentation and the code base execution in the jupyter notebook uploaded in this repository
